import { NextResponse } from 'next/server';
import { getGoogle, getGoogleForTenant, loadAllForTenant } from '@/lib/dataStore';
import { getSessionUser, getSessionTenantId } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  if (!getSessionUser()) return NextResponse.json({error:'Unauthorized'},{status:401});
  
  const tenantId = getSessionTenantId();
  if (tenantId) {
    // Ensure tenant data is loaded
    loadAllForTenant(tenantId);
    return NextResponse.json(getGoogleForTenant(tenantId));
  }
  
  // Legacy fallback
  return NextResponse.json(getGoogle());
}